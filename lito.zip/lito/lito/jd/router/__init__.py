from .ro_sector_publico import sector_publico_scope
from .ro_cadena_iva import papel_trabajo_scope
from .ro_seguridad import pages
from .ro_tablero import dashboards
from .ro_papeles import papel_portal
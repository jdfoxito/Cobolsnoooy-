/*
Template JS: SRI -  development javascript
Author: jagonzalezj
WebSite: https://www.sri.gob.ec
Contact: jagonzalezj@sri.gob.ec
File: Animatoin aos Js File
*/

AOS.init({
	easing: 'ease-out-back',
	duration: 1000
});